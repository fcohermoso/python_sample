import json
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import base64
import plugintools
from core import httptools

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version="(v0.0.3)"

base = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2Zjb2hlcm1vc28vcHl0aG9uX3NhbXBsZS9yZWZzL2hlYWRzL21haW4vc3RhdGljL2Jhc2UudHh0"

horus = "eydhY3Rpb24nOiAncGxheScsICdmYW5hcnQnOiAnTUktRkFOQVJUJywgJ2ljb24nOiAnTUktSUNPTk8nLCAnaWQnOiAnTUktSUQtQUNFJywgJ2xhYmVsJzogJ01JLVRJVFVMTyd9"  ##Para id-Aces

# Punto de Entrada
def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list()
	else:
		action = params.get("action")
		exec(action+"(params)")

	plugintools.close_item_list()

# Principal
def main_list():
    opciones = base64.b64decode(httptools.downloadpage(base64.b64decode(base.encode('utf-8')).decode('utf-8')).data).decode('utf-8')
    canales = json.loads(opciones)

    for nombre, parametro in canales.items():
        reemplaza = base64.b64decode(horus.encode('utf-8')).decode('utf-8').replace("MI-ID-ACE" , parametro)
        reemplaza = reemplaza.replace("MI-FANART" , "")
        reemplaza = reemplaza.replace("MI-ICONO" , "")
        reemplaza = reemplaza.replace("MI-TITULO" , nombre)

        mivideo = "plugin://script.module.horus/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')

        plugintools.add_item(action="play", url=mivideo, title=nombre, genre="NOGESTIONAR", thumbnail="", fanart="", folder=False, isPlayable=False)

def play(params):
    mivideo = params.get("url")
    logo = params.get("thumbnail")
    titu = params.get("title")
    titulo = params.get("extra")
    
    xbmc.Player().play(mivideo)

if __name__ == '__main__':
    run()
