import json
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import base64
import plugintools
from core import httptools

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version="(v0.0.3)"

base = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2Zjb2hlcm1vc28vcHl0aG9uX3NhbXBsZS9yZWZzL2hlYWRzL21haW4vc3RhdGljL2Jhc2UudHh0"
baseMoDz = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL01vRHoxNy9JUFRWX01vRHovbWFpbi9jb2RlX2lwdHY="
baseLista2 = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2FsYmVydGZnOTcvQWNlU3RyZWFtQ2hhbm5lbHMvcmVmcy9oZWFkcy9tYWluL0NhbmFsZXMubTN1"

horus = "eydhY3Rpb24nOiAncGxheScsICdmYW5hcnQnOiAnTUktRkFOQVJUJywgJ2ljb24nOiAnTUktSUNPTk8nLCAnaWQnOiAnTUktSUQtQUNFJywgJ2xhYmVsJzogJ01JLVRJVFVMTyd9"  ##Para id-Aces

opciones_modz = httptools.downloadpage(base64.b64decode(baseMoDz.encode('utf-8')).decode('utf-8')).data
canales_modz = json.loads(opciones_modz)

# Punto de Entrada
def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list()
	else:
		action = params.get("action")
		exec(action+"(params)")

	plugintools.close_item_list()

# Principal
def main_list():

    plugintools.add_item(action="modz",url="",title='[COLOR mediumaquamarine]MoDz[/COLOR]', folder=True, isPlayable=False)
    plugintools.add_item(action="lista2",url="",title='[COLOR mediumaquamarine]Lista 2[/COLOR]', folder=True, isPlayable=False)


    # opciones = base64.b64decode(httptools.downloadpage(base64.b64decode(base.encode('utf-8')).decode('utf-8')).data).decode('utf-8')
    # canales = json.loads(opciones)

    # for nombre, parametro in canales.items():
    #     reemplaza = base64.b64decode(horus.encode('utf-8')).decode('utf-8').replace("MI-ID-ACE" , parametro)
    #     reemplaza = reemplaza.replace("MI-FANART" , "")
    #     reemplaza = reemplaza.replace("MI-ICONO" , "")
    #     reemplaza = reemplaza.replace("MI-TITULO" , nombre)

    #     mivideo = "plugin://script.module.horus/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')

    #     plugintools.add_item(action="play", url=mivideo, title=nombre, genre="NOGESTIONAR", thumbnail="", fanart="", folder=False, isPlayable=False)

def play(params):
    mivideo = params.get("url")
    xbmc.Player().play(mivideo)

def modz(params):
    for group in canales_modz.get("groups", []):
        if group.get("name") == "Zona Ace":
            for subgroup in group.get("groups", []):
                if subgroup.get("name") in ["Zona Movistar+", "Zona DAZN"]:
                    plugintools.add_item(action="modz_subgroups", url="", title=subgroup.get("name"), thumbnail=subgroup.get("image"), fanart=subgroup.get("image"), folder=True, isPlayable=False)

def modz_subgroups(params):
    stations = []
    stations_names = []
    for group in canales_modz.get("groups", []):
        if group.get("name") == "Zona Ace":
            for subgroup in group.get("groups", []):
                if subgroup.get("name") in [params.get("title")]:
                    for station in subgroup.get("stations", []):
                        if station["name"] not in stations_names:
                            stations.append(station)
                            stations_names.append(station["name"])

    for station in stations:
        reemplaza = base64.b64decode(horus.encode('utf-8')).decode('utf-8').replace("MI-ID-ACE" , station.get("url").replace("acestream://" , ""))
        reemplaza = reemplaza.replace("MI-FANART" , "")
        reemplaza = reemplaza.replace("MI-ICONO" , "")
        reemplaza = reemplaza.replace("MI-TITULO" , station.get("name"))

        mivideo = "plugin://script.module.horus/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')

        plugintools.add_item(action="play", url=mivideo, title=station.get("name"), genre="", thumbnail=station.get("image"), fanart=station.get("image"), folder=False, isPlayable=False)

def lista2(params):

    listaDoble = httptools.downloadpage(base64.b64decode(baseLista2.encode('utf-8')).decode('utf-8')).data
    listaDoble = listaDoble + "#"
      
    acotacion = "EXTINF:-1"
    acotaFin = "#"
    canales = plugintools.find_multiple_matches(listaDoble,acotacion+'(.*?)'+acotaFin)
    for item in canales:
        item = item + "#"
        plugintools.log("*****************Item: "+item+"********************")
        titulo = plugintools.find_single_match(item,'tvg-id="(.*?)"')
        logo = plugintools.find_single_match(item,'tvg-logo="(.*?)"')
        acotacion = "acestream://"
        acotaFin = "#"
        link = plugintools.find_single_match(item,acotacion+'(.*?)'+acotaFin).replace("\r\n" , "").replace("\n" , "")
        plugintools.log("*****************Link: "+link+"********************")
        titu = "[COLOR white]" + titulo + "[/COLOR]"
        if len(titulo) > 0:
            reemplaza = base64.b64decode(horus.encode('utf-8')).decode('utf-8').replace("MI-ID-ACE" , link)
            reemplaza = reemplaza.replace("MI-FANART" , "")
            reemplaza = reemplaza.replace("MI-ICONO" , "")
            reemplaza = reemplaza.replace("MI-TITULO" , titulo)
            
            mivideo = "plugin://script.module.horus/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        
            plugintools.add_item(action="play", url=mivideo, title=titu, genre="", thumbnail=logo, fanart=logo, folder=False, isPlayable=False)
    
     
if __name__ == '__main__':
    run()
